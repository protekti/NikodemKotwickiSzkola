﻿using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private Random random = new Random();
        private int clickCount = 0;
        private Stopwatch stopwatch = new Stopwatch();
        private decimal bestTime = decimal.MaxValue; // Zmienna do przechowywania najlepszego czasu
        private TextBlock wynik;
        private string[] imageUris =
        {
            "pack://application:,,,/Images/gargamel.png",
            "pack://application:,,,/Images/pobrane (1).jpg",
                "pack://application:,,,/Images/pobrane (2).jpg",
                "pack://application:,,,/Images/pobrane.jpg"
        };

        public MainWindow()
        {
            InitializeComponent();
            StartGame();
            Najlepszywynik();
        }

        private void StartGame()
        {
            // Tworzenie przycisku
            Button button = new Button();
            button.Width = 150;
            button.Height = 150;

            // Tworzenie obrazu
            Image image = new Image();
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            string selceted = imageUris[random.Next(imageUris.Length)];
            bitmap.UriSource = new Uri(selceted);
            bitmap.EndInit();
            image.Source = bitmap;

            // Dodanie obrazu do przycisku
            button.Content = image;
            button.Click += Button_Click;
            Grid.SetZIndex(button, 1); // Umieszczamy przycisk na wierzchu
            mainGrid.Children.Add(button);
            PlaceButtonRandomly(button);
            stopwatch.Start();
        }
        private void Najlepszywynik()
        {
            wynik = new TextBlock
            {
                Width = 400,
                Height = 25,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Top,
                TextAlignment = TextAlignment.Center,
                Text = $"Najlepszy wynik:",
                FontSize = 15
            };
            mainGrid.Children.Add(wynik);

        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            mainGrid.Children.Remove(button);
            clickCount++;

            if (clickCount == 10)
            {
                stopwatch.Stop();
                decimal czas = (decimal)stopwatch.ElapsedMilliseconds / 1000;

                // Sprawdzenie, czy czas jest lepszy od dotychczasowego rekordu
                if (czas < bestTime)
                {
                    bestTime = czas;
                    MessageBox.Show(this, $"Gratulacje! Twój czas to: {czas:F1} s. Ustanowiłeś nowy rekord!");
                    wynik.Text = $"Najlepszy wynik: {bestTime:F1} sekund"; 
                }
                else
                {
                    MessageBox.Show(this, $"Gratulacje! Twój czas to: {czas:F1} s. Twój najlepszy czas to: {bestTime:F1} s.");
                }

                StartGame();
                clickCount = 0;
                stopwatch.Restart();
            }
            else
            {
                StartGame();
            }
        }

        private void PlaceButtonRandomly(Button button)
        {
            // Pobierz aktualne wymiary siatki i przycisku
            int maxWidth = (int)(mainGrid.ActualWidth - button.Width);
            int maxHeight = (int)(mainGrid.ActualHeight - button.Height);

            // Sprawdź, czy wymiary są poprawne (czy przycisk zmieści się w siatce)
            if (maxWidth > 0 && maxHeight > 0)
            {
                // Generuj losowe współrzędne dla przycisku
                int left = random.Next(10, maxWidth);
                int top = random.Next(10, maxHeight);

                // Ustaw pozycję przycisku
                button.Margin = new Thickness(left, top, 0, 0);
                button.HorizontalAlignment = HorizontalAlignment.Left;
                button.VerticalAlignment = VerticalAlignment.Top;
            }
        }
    }
}
