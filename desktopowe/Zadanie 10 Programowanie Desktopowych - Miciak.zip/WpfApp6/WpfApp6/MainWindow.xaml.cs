﻿using System;
using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace WpfApp6
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Zadanie 1: Oblicz pierwiastek kwadratowy
        private void ObliczPierwiastek_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ErrorSqrt.Text = string.Empty;
                ResultSqrt.Text = string.Empty;

                double number = double.Parse(InputNumber.Text);
                double result = ObliczPierwiastek(number);
                ResultSqrt.Text = $"Pierwiastek: {result}";
            }
            catch (ArgumentOutOfRangeException ex)
            {
                ErrorSqrt.Text = ex.Message;
            }
            catch (Exception ex)
            {
                ErrorSqrt.Text = $"Nieoczekiwany błąd: {ex.Message}";
            }
        }

        private double ObliczPierwiastek(double number)
        {
            if (number < 0)
                throw new ArgumentOutOfRangeException("Liczba nie może być ujemna.");
            return Math.Sqrt(number);
        }

        // Zadanie 2: Wczytaj dane z pliku
        private void WczytajDane_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                FileError.Text = string.Empty;
                FileResult.Text = string.Empty;

                OpenFileDialog openFileDialog = new OpenFileDialog
                {
                    Title = "Wybierz plik do wczytania",
                    Filter = "Pliki tekstowe (*.txt)|*.txt|Wszystkie pliki (*.*)|*.*"
                };

                if (openFileDialog.ShowDialog() == true)
                {
                    string filePath = openFileDialog.FileName;
                    int number = WczytajDane(filePath);
                    FileResult.Text = $"Wczytano liczbę: {number}";
                }
                else
                {
                    FileError.Text = "Nie wybrano pliku.";
                }
            }
            catch (FileNotFoundException ex)
            {
                FileError.Text = $"Plik nie został znaleziony: {ex.Message}";
            }
            catch (FormatException ex)
            {
                FileError.Text = $"Nieprawidłowy format danych: {ex.Message}";
            }
            catch (Exception ex)
            {
                FileError.Text = $"Nieoczekiwany błąd: {ex.Message}";
            }
        }

        private int WczytajDane(string filePath)
        {
            string content = File.ReadAllText(filePath);
            return int.Parse(content);
        }

        // Zadanie 3: Sprawdź temperaturę
        private void SprawdzTemperature_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                TempError.Text = string.Empty;
                TempResult.Text = string.Empty;

                double temperature = double.Parse(InputTemperature.Text);
                SprawdzTemperature(temperature);
                TempResult.Text = "Temperatura jest w dopuszczalnym zakresie.";
            }
            catch (ArgumentOutOfRangeException ex)
            {
                TempError.Text = ex.Message;
            }
            catch (Exception ex)
            {
                TempError.Text = $"Nieoczekiwany błąd: {ex.Message}";
            }
        }

        private void SprawdzTemperature(double temperature)
        {
            if (temperature < -50 || temperature > 50)
                throw new ArgumentOutOfRangeException("Temperatura musi być w zakresie -50 do 50 stopni.");
        }
    }
}
